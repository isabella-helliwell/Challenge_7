------------------------------------Deliverable 1-----------------------------------
-----------------------------------------------------------------------------------
--1. Retrieve the emp_no, first_name, and last_name columns from the Employees table.
--2.Retrieve the title, from_date, and to_date columns from the Titles table.
--3.Create a new table using the INTO clause.
--4.Join both tables on the primary key.
--5.Filter the data on the birth_date column to retrieve the employees who were born between 1952 and 1955. Then, order by the employee number.
--6.Export the Retirement Titles table from the previous step as retirement_titles.csv and save it to your Data folder in the Pewlett-Hackard-Analysis folder.

---------------------------DELIVERABLE 1-----------------------------------

---part1.1----------------------
SELECT employees.emp_no, employees.first_name, employees.last_name,
	   titles.title, titles.from_date, titles.to_date
INTO retirement_titles
FROM employees
INNER JOIN titles
ON (employees.emp_no=titles.emp_no)
WHERE (employees.birth_date BETWEEN '1952-01-01' AND '1955-12-31')
ORDER BY employees.emp_no;
SELECT * FROM retirement_titles


----------part 1.2- Remove the duplicates and keep only the most recent title of each employee-------
SELECT DISTINCT ON (emp_no) emp_no,
first_name,
last_name,
title
INTO unique_titles
FROM retirement_titles
ORDER BY emp_no,to_date DESC;
SELECT * FROM unique_titles

-----part 1.3------
---retrieve the number of titles from the unique_titles table, save it to a new table, and group by title, and sort the 
-----count column in descending order
SELECT COUNT (title), title
INTO retiring_titles
FROM unique_titles
GROUP BY title 
ORDER BY COUNT DESC;

SELECT * FROM retiring_titles limit 10;

------DELIVERABLE 2--------

SELECT employees.emp_no, employees.first_name, employees.last_name,employees.birth_date,
	   titles.title, dept_emp.from_date, dept_emp.to_date
INTO mentor_candidates   
FROM employees
LEFT JOIN dept_emp
ON (employees.emp_no=dept_emp.emp_no)
INNER JOIN titles
ON(employees.emp_no=titles.emp_no)
WHERE(employees.birth_date BETWEEN '1965-01-01' AND '1965-12-31')
AND (dept_emp.to_date='9999-01-01')

 
SELECT DISTINCT ON (emp_no) emp_no,
first_name,
last_name,
birth_date,
from_date,
to_date,
title
INTO mentorship_eligibilty
FROM mentor_candidates
ORDER BY emp_no, title Asc;

SELECT * FROM mentorship_eligibilty











-------
-----------
--------testing testing-----

SELECT DISTINCT ON (emp_no) emp_no,
first_name,
last_name,
title
--INTO unique_titles_2
FROM retirement_titles
ORDER BY emp_no, from_date DESC;
SELECT * FROM unique_titles
SELECT * FROM retirement_titles;









		




